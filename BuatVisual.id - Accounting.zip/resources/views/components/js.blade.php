<script data-cfasync="false" src="{{ asset('') }}js/email-decode.min.js"></script>
<script type="text/javascript" src="{{ asset('') }}js/jquery.js"></script>
{{-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js" ></script> --}}
<script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="{{ asset('') }}js/jquery-ui.min.js"></script>
<script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="{{ asset('') }}js/popper.min.js"></script>
<script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="{{ asset('') }}js/bootstrap.min.js"></script>

<script src="{{ asset('') }}js/waves.min.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>

<script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="{{ asset('') }}js/jquery.slimscroll.js"></script>

<script src="{{ asset('') }}js/jquery.flot.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
<script src="{{ asset('') }}js/jquery.flot.categories.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
<script src="{{ asset('') }}js/curvedlines.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
<script src="{{ asset('') }}js/jquery.flot.tooltip.min.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript">
</script>
<script src="{{ asset('') }}js/select2.full.min.js"></script>

<script src="{{ asset('') }}js/bootstrap-multiselect.js">
</script>
<script src="{{ asset('') }}js/jquery.multi-select.js"></script>
<script src="{{ asset('') }}js/jquery.quicksearch.js"></script>

<script src="{{ asset('') }}js/select2-custom.js"></script>
<script src="{{ asset('') }}js/chartist.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>

{{-- <script src="{{ asset('') }}js/amcharts.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script> --}}
<script src="{{ asset('') }}js/serial.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
<script src="{{ asset('') }}js/light.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>

<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>
<script src="https://code.highcharts.com/modules/accessibility.js"></script>

<script src="{{ asset('') }}js/pcoded.min.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
<script src="{{ asset('') }}js/vertical-layout.min.js" type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
<script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="{{ asset('') }}js/custom-dashboard.min.js"></script>
<script type="d2d1d6e2f87cbebdf4013b26-text/javascript" src="{{ asset('') }}js/script.min.js"></script>

{{-- custom js --}}
<script src="{{ asset('') }}js/script/custom.js"></script>

<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"
type="d2d1d6e2f87cbebdf4013b26-text/javascript"></script>
<script type="d2d1d6e2f87cbebdf4013b26-text/javascript">
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'UA-23581568-13');
</script>
<script src="{{ asset('') }}js/rocket-loader.min.js" data-cf-settings="d2d1d6e2f87cbebdf4013b26-|49" defer="">
</script>
