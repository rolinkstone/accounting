<nav class="navbar header-navbar pcoded-header">
  <div class="navbar-wrapper">
      <div class="navbar-logo">
          <a href="<?php echo e(route('dashboard')); ?>">
            <i class="ti-pencil-alt"></i> <strong> Accounting</strong>
              
          </a>
          <a class="mobile-menu" id="mobile-collapse" href="#!">
              <i class="feather icon-menu icon-toggle-right"></i>
          </a>
          <a class="mobile-options waves-effect waves-light">
              <i class="feather icon-more-horizontal"></i>
          </a>
      </div>
      <div class="navbar-container container-fluid">
          <ul class="nav-left">
              <li class="header-search">
                  <div class="main-search morphsearch-search">
                      <div class="input-group">
                          <span class="input-group-prepend search-close">
                              <i class="feather icon-x input-group-text"></i>
                          </span>
                          <input type="text" class="form-control" placeholder="Enter Keyword">
                          <span class="input-group-append search-btn">
                              <i class="feather icon-search input-group-text"></i>
                          </span>
                      </div>
                  </div>
              </li>
              <li>
                  <a href="#!"
                      onclick="if (!window.__cfRLUnblockHandlers) return false; javascript:toggleFullScreen()"
                      class="waves-effect waves-light" data-cf-modified-d8424a08d31b5b8b406fded2-="">
                      <i class="full-screen feather icon-maximize"></i>
                  </a>
              </li>
          </ul>
          <ul class="nav-right">
              <li class="header-notification">
                  <div class="dropdown-primary dropdown">
                      
                  </div>
              </li>
              
              <li class="user-profile header-notification">
                  <div class="dropdown-primary dropdown">
                      <div class="dropdown-toggle" data-toggle="dropdown">
                          
                          <span><?php echo e(auth()->user()->name); ?></span>
                          <i class="feather icon-chevron-down"></i>
                      </div>
                      <ul class="show-notification profile-notification dropdown-menu"
                          data-dropdown-in="fadeIn" data-dropdown-out="fadeOut">
                          <li>
                              <a href="<?php echo e(route('change_password')); ?>">
                                  <i class="feather icon-settings"></i> Ganti Password
                              </a>
                          </li>
                          
                          <li>
                              <a class="dropdown-item" href="#" data-toggle="modal"
                                  data-target="#exampleModal">
                                  <i class="feather icon-log-out"></i>
                                  Logout
                              </a>
                          </li>
                      </ul>
                  </div>
              </li>
          </ul>
      </div>
  </div>
</nav>
<?php /**PATH D:\Compressed\accounting-main\accounting-main\resources\views/components/navbar.blade.php ENDPATH**/ ?>