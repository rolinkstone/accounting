<?php $__env->startPush('custom-styles'); ?>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('')); ?>css/themify-icons.css">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('')); ?>css/icofont.css">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('')); ?>css/font-awesome.min.css">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('')); ?>css/notification.css">

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('')); ?>css/animate.css">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('')); ?>css/pages.css">
<?php $__env->stopPush(); ?>

<?php if(session('status')): ?>
    <div class="alert alert-success background-success">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <i class="icofont icofont-close-line-circled text-white"></i>
        </button>
        <strong><?php echo e(session('status')); ?></strong>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger background-danger">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <i class="icofont icofont-close-line-circled text-white"></i>
        </button>
        <strong><?php echo e(session('error')); ?></strong>
    </div>
<?php endif; ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script type="bc9e5e682d42f376717182ab-text/javascript" src="<?php echo e(asset('')); ?>js/modernizr.js"></script>
    <script type="bc9e5e682d42f376717182ab-text/javascript" src="<?php echo e(asset('')); ?>js/css-scrollbars.js"></script>

    <script type="bc9e5e682d42f376717182ab-text/javascript" src="<?php echo e(asset('')); ?>js/bootstrap-growl.min.js"></script>
    <script type="bc9e5e682d42f376717182ab-text/javascript" src="<?php echo e(asset('')); ?>js/notification.js"></script>
    <script src="<?php echo e(asset('')); ?>js/pcoded.min.js" type="bc9e5e682d42f376717182ab-text/javascript"></script>
    <script src="<?php echo e(asset('')); ?>js/vertical-layout.min.js" type="bc9e5e682d42f376717182ab-text/javascript"></script>
    <script src="<?php echo e(asset('')); ?>js/jquery.mcustomscrollbar.concat.min.js"
        type="bc9e5e682d42f376717182ab-text/javascript"></script>

    <script type="bc9e5e682d42f376717182ab-text/javascript" src="<?php echo e(asset('')); ?>js/script.js"></script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\Compressed\accounting-main\accounting-main\resources\views/components/notification.blade.php ENDPATH**/ ?>